package com.asthabansal.weatherapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.asthabansal.weatherapp.databinding.ActivityMainBinding
import org.json.JSONObject
import java.net.URL
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var activityMainBinding: ActivityMainBinding

    private var apiKey = "74f6bb6d6024f7a6e1049699f9a4dbe0"
    private var cityName = "bielsko-biala,pl"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(activityMainBinding.root)

        activityMainBinding.sendButton.setOnClickListener {
            cityName = activityMainBinding.cityEditText.text.toString()
            fetchWeatherData()
        }

        fetchWeatherData()
    }

    private fun fetchWeatherData() {
        activityMainBinding.loader.visibility = View.VISIBLE
        activityMainBinding.mainContainerRelativeLayout.visibility = View.GONE
        activityMainBinding.tvError.visibility = View.GONE

        Thread {
            var response: String? = null
            try {
                val url = URL("https://api.openweathermap.org/data/2.5/weather?q=$cityName&units=metric&appid=$apiKey")
                response = url.readText(Charsets.UTF_8)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            runOnUiThread {
                if (!response.isNullOrEmpty()) {
                    try {
                        val jsonObj = JSONObject(response)
                        val main = jsonObj.getJSONObject("main")
                        val sys = jsonObj.getJSONObject("sys")
                        val weather = jsonObj.getJSONArray("weather").getJSONObject(0)

                        val temp = main.getString("temp") + "°C"

                        val weatherDescription = weather.getString("description")
                        val address = jsonObj.getString("name") + ", " + sys.getString("country")
                        when {
                            weatherDescription.contains("clouds", ignoreCase = true) -> {
                                activityMainBinding.background.setBackgroundResource(R.drawable.chmury)
                            }

                            weatherDescription.contains("rain", ignoreCase = true) -> {
                                activityMainBinding.background.setBackgroundResource(R.drawable.rainn)
                            }

                            weatherDescription.contains("sky", ignoreCase = true) -> {
                                activityMainBinding.background.setBackgroundResource(R.drawable.sunny)
                            }

                            else -> {
                                activityMainBinding.background.setBackgroundResource(R.drawable.chmury)
                            }
                        }

                        activityMainBinding.address.text = address
                        activityMainBinding.status.text = weatherDescription.replaceFirstChar {
                            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
                        }
                        activityMainBinding.temp.text = temp

                        activityMainBinding.loader.visibility = View.GONE
                        activityMainBinding.tvError.visibility = View.GONE
                        activityMainBinding.mainContainerRelativeLayout.visibility = View.VISIBLE
                    } catch (e: Exception) {
                        e.printStackTrace()
                        activityMainBinding.loader.visibility = View.GONE
                        activityMainBinding.tvError.visibility = View.VISIBLE
                    }
                } else {
                    activityMainBinding.loader.visibility = View.GONE
                    activityMainBinding.tvError.visibility = View.VISIBLE
                }
            }
        }.start()
    }
}
